<?php
include('includes/pdoconfig.php');
if(!empty($_POST["roomid"])) 
{	
$id=$_POST['roomid'];
$stmt = $DB_con->prepare("SELECT * FROM rooms WHERE room_no = :id");
$stmt->execute(array(':id' => $id));
?>
 <?php
 while($row=$stmt->fetch(PDO::FETCH_ASSOC))
 {
  ?>
 <?php echo htmlentities($row['seater']); ?>
  <?php
 }
}

if(isset($_POST["faculty"])) 
{	
$faculty="";
$id=$_POST['faculty'];
$stmt = $DB_con->prepare("SELECT * FROM faculty WHERE course_fn = :id");
$stmt->execute(array(':id' => $id));
while($row=$stmt->fetch(PDO::FETCH_ASSOC))
 {
$faculty = $row['course_sn']; 

 }
 
$stmt = $DB_con->prepare("SELECT * FROM courses WHERE faculty = :faculty");
$stmt->execute(array(':faculty' => $faculty));
?>

  <div class="form-group">
<label class="col-sm-2 control-label">course </label>
<div class="col-sm-8">

  <select name="course" id="course" class="form-control"  > 
<option value="">Select Course</option>
 <?php

 while($row=$stmt->fetch(PDO::FETCH_ASSOC))
 {
  ?>

  
 <option value="<?php echo $row['course_fn'];?>"><?php echo $row['course_fn'];?>(<?php echo $row['course_sn']; ?>)</option>

  <?php
 }
?> </select>
 </div>
</div><?php
}


if(!empty($_POST["rid"])) 
{	
$id=$_POST['rid'];
$stmt = $DB_con->prepare("SELECT * FROM rooms WHERE room_no = :id");
$stmt->execute(array(':id' => $id));
?>
 <?php
 while($row=$stmt->fetch(PDO::FETCH_ASSOC))
 {
  ?>
 <?php echo htmlentities($row['fees']); ?>
  <?php
 }
}


?>