
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>PHP and JS</title>
<script type="text/javascript">
function areaOfSphere(radius) { return 4 * Math.PI * (Math.pow(radius, 2)); }
</script>
</head>
<?php
$rad = 7
?>
<body>
<form name="arr" method="post" >
<input type="text" name="area" id="area" onMouseOver="<?php return areaOfSphere($rad) ?>">
</form>
<?php
$name = $_GET['name'];
echo 'Welcome to our web site, ' . $name . '!';
?>
</body>
</html>